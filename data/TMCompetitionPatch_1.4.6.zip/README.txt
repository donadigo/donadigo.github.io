Installation:
1) Unpack all the files into your Trackmania installation directory. This is by default 
C:\Program Files (x86)\TmNationsForever or C:\Program Files (x86)\TmUnitedForever.
2) Done!

VC++ 2019 redistributables are provided in "local deployment" mode.