Installation:
1) Unpack all the files into your Trackmania installation directory. This is by default 
C:\Program Files (x86)\TmNationsForever or C:\Program Files (x86)\TmUnitedForever.
2) Done!